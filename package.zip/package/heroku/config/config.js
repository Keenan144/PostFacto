window.Retro = {
  config: {
    "globalNamespace": "Retro",
    "title": "Postfacto",
    "scripts": ["application.js"],
    "stylesheets": ["application.css"],
    "useRevManifest": true,
    "api_base_url": "https://{{api-app-name}}.herokuapp.com",
    "websocket_url": "wss://{{api-app-name}}.herokuapp.com/cable",
    "contact": "",
    "terms": "",
    "privacy": ""
  }
}

